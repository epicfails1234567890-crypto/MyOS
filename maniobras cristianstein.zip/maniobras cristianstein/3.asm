[org 0x7c00]

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    sti

    ; Limpiar pantalla al iniciar
    call do_clear

main_loop:
    mov si, prompt
    call print_string

    mov di, buffer

read_loop:
    mov ah, 0x00
    int 0x16              ; Leer tecla del teclado
    
    cmp al, 0x0D          ; Si es ENTER
    je parse_cmd
    
    cmp al, 0x08          ; Si es BACKSPACE (Borrar)
    je handle_backspace
    
    cmp di, buffer + 30   ; Límite del búfer
    jge read_loop

    stosb                 ; Guardar carácter en el búfer
    mov ah, 0x0E
    int 0x10              ; Mostrar carácter en pantalla
    jmp read_loop

handle_backspace:
    cmp di, buffer
    jle read_loop
    dec di
    mov ah, 0x0E
    mov al, 0x08
    int 0x10
    mov al, ' '
    int 0x10
    mov al, 0x08
    int 0x10
    jmp read_loop

parse_cmd:
    mov byte [di], 0      ; Terminar la cadena con cero
    mov si, newline
    call print_string

    ; 1. Comparar con "clear"
    mov si, buffer
    mov di, cmd_clear
    call strcmp
    jc do_clear

    ; 2. Comparar con "help"
    mov si, buffer
    mov di, cmd_help
    call strcmp
    jc do_help

    ; 3. Comprobar si empieza con "echo "
    mov si, buffer
    mov di, cmd_echo
    call strncmp          ; Comprueba los primeros 5 caracteres ("echo ")
    jc do_echo

    ; Si no coincide con ninguno
    mov si, msg_unknown
    call print_string
    jmp main_loop

do_clear:
    mov ah, 0x00
    mov al, 0x03          ; Modo texto 80x25 (limpia pantalla)
    int 0x10
    jmp main_loop

do_help:
    mov si, msg_help
    call print_string
    jmp main_loop

do_echo:
    ; SI apunta al texto después de "echo " (gracias a strncmp)
    call print_string
    mov si, newline
    call print_string
    jmp main_loop

print_string:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0E
    int 0x10
    jmp print_string
.done:
    ret

; Compara cadena exacta (devuelve Carry si es igual)
strcmp:
    push si
    push di
.loop:
    lodsb
    mov bl, [di]
    inc di
    cmp al, bl
    jne .notequal
    or al, al
    jz .equal
    jmp .loop
.equal:
    pop di
    pop si
    stc
    ret
.notequal:
    pop di
    pop si
    clc
    ret

; Compara los primeros 5 bytes (para "echo ") y deja SI apuntando al texto restante
strncmp:
    push di
.loop:
    mov al, [di]
    cmp al, 0             ; Si llegamos al final de la cadena a comparar
    je .equal
    mov bl, [si]
    cmp bl, 0
    jne .check
    cmp al, 0             ; Si ambos terminan a la vez
    je .equal
.check:
    cmp bl, al
    jne .notequal
    inc si
    inc di
    jmp .loop
.equal:
    pop di
    stc                   ; Coincide el prefijo "echo "
    ret
.notequal:
    pop di
    clc
    ret

prompt      db '>', 0
newline     db 13, 10, 0
cmd_clear   db 'clear', 0
cmd_help    db 'help', 0
cmd_echo    db 'echo ', 0
msg_unknown db 'Comando no reconocido. Escribe help.', 13, 10, 0
msg_help    db 'Comandos disponibles:', 13, 10, ' - clear: Limpia la pantalla', 13, 10, ' - help: Muestra esta ayuda', 13, 10, ' - echo [texto]: Imprime texto', 13, 10, 0
buffer      times 32 db 0

    times 510-($-$$) db 0
    dw 0xAA55