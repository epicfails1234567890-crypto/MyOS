[org 0x7c00]

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    sti
    call do_clear

main_loop:
    mov si, prompt
    call print_string
    mov di, buffer

read_loop:
    mov ah, 0x00
    int 0x16
    cmp al, 0x0D
    je parse_cmd
    cmp al, 0x08
    je handle_bs
    cmp di, buffer + 24
    jge read_loop
    stosb
    mov ah, 0x0E
    int 0x10
    jmp read_loop

handle_bs:
    cmp di, buffer
    jle read_loop
    dec di
    mov ah, 0x0E
    mov al, 0x08
    int 0x10
    mov al, ' '
    int 0x10
    mov al, 0x08
    int 0x10
    jmp read_loop

parse_cmd:
    mov byte [di], 0
    mov si, newline
    call print_string

    mov si, buffer
    mov di, c_clear
    call strcmp
    jc do_clear

    mov si, buffer
    mov di, c_help
    call strcmp
    jc do_help

    mov si, buffer
    mov di, c_date
    call strcmp
    jc do_date

    mov si, buffer
    mov di, c_time
    call strcmp
    jc do_time

    mov si, buffer
    mov di, c_echo
    call strncmp
    jc do_echo

    mov si, msg_unk
    call print_string
    jmp main_loop

do_clear:
    mov ax, 0x0003
    int 0x10
    jmp main_loop

do_help:
    mov si, msg_help
    call print_string
    jmp main_loop

do_echo:
    call print_string
    mov si, newline
    call print_string
    jmp main_loop

do_date:
    mov ah, 0x04
    int 0x1a
    mov al, dh
    call p_bcd
    mov al, '/'
    int 0x10
    mov al, dl
    call p_bcd
    mov al, '/'
    int 0x10
    mov al, ch
    call p_bcd
    mov al, cl
    call p_bcd
    mov si, newline
    call print_string
    jmp main_loop

do_time:
    mov ah, 0x02
    int 0x1a
    mov al, ch
    call p_bcd
    mov al, ':'
    int 0x10
    mov al, cl
    call p_bcd
    mov al, ':'
    int 0x10
    mov al, dh
    call p_bcd
    mov si, newline
    call print_string
    jmp main_loop

p_bcd:
    push ax
    shr al, 4
    call p_dig
    pop ax
p_dig:
    and al, 0x0F
    add al, '0'
    mov ah, 0x0E
    int 0x10
    ret

print_string:
    lodsb
    test al, al
    jz .done
    mov ah, 0x0E
    int 0x10
    jmp print_string
.done:
    ret

strcmp:
    push si
    push di
.l:
    lodsb
    mov bl, [di]
    inc di
    cmp al, bl
    jne .no
    test al, al
    jz .yes
    jmp .l
.yes:
    pop di
    pop si
    stc
    ret
.no:
    pop di
    pop si
    clc
    ret

strncmp:
    push di
.l:
    mov al, [di]
    test al, al
    jz .yes
    mov bl, [si]
    cmp bl, al
    jne .no
    inc si
    inc di
    jmp .l
.yes:
    pop di
    stc
    ret
.no:
    pop di
    clc
    ret

prompt  db '>', 0
newline db 13, 10, 0
c_clear db 'clear', 0
c_help  db 'help', 0
c_date  db 'date', 0
c_time  db 'time', 0
c_echo  db 'echo ', 0
msg_unk   db 'Cmd err. Type help', 13, 10, 0
msg_help  db 'clear, help, date, time, echo [txt]', 13, 10, 0
buffer    times 24 db 0

times 510-($-$$) db 0
dw 0xAA55