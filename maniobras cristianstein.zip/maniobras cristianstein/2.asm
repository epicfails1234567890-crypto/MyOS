[org 0x7c00]

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    sti

    ; Limpiar pantalla al iniciar
    call do_clear

main_loop:
    mov si, prompt
    call print_string

    mov di, buffer

read_loop:
    mov ah, 0x00
    int 0x16              ; Leer tecla del teclado
    
    cmp al, 0x0D          ; Si es ENTER (Carriage Return)
    je parse_cmd
    
    cmp al, 0x08          ; Si es BACKSPACE (Borrar)
    je handle_backspace
    
    cmp di, buffer + 30   ; Límite del búfer
    jge read_loop

    stosb                 ; Guardar carácter en el búfer
    mov ah, 0x0E
    int 0x10              ; Mostrar carácter en pantalla
    jmp read_loop

handle_backspace:
    cmp di, buffer
    jle read_loop
    dec di
    mov ah, 0x0E
    mov al, 0x08
    int 0x10
    mov al, ' '
    int 0x10
    mov al, 0x08
    int 0x10
    jmp read_loop

parse_cmd:
    mov byte [di], 0      ; Terminar la cadena con cero
    mov si, newline
    call print_string

    ; Comparar con "clear"
    mov si, buffer
    mov di, cmd_clear
    call strcmp
    jc do_clear

    ; Comparar con "help"
    mov si, buffer
    mov di, cmd_help
    call strcmp
    jc do_help

    ; Si no coincide con ninguno
    mov si, msg_unknown
    call print_string
    jmp main_loop

do_clear:
    mov ah, 0x00
    mov al, 0x03          ; Modo texto 80x25 (limpia pantalla)
    int 0x10
    jmp main_loop

do_help:
    mov si, msg_help
    call print_string
    jmp main_loop

print_string:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0E
    int 0x10
    jmp print_string
.done:
    ret

strcmp:
    push si
    push di
.loop:
    lodsb
    mov bl, [di]
    inc di
    cmp al, bl
    jne .notequal
    or al, al
    jz .equal
    jmp .loop
.equal:
    pop di
    pop si
    stc                   ; Carry Flag activada = Coincide
    ret
.notequal:
    pop di
    pop si
    clc                   ; Carry Flag desactivada = No coincide
    ret

prompt      db '>', 0
newline     db 13, 10, 0
cmd_clear   db 'clear', 0
cmd_help    db 'help', 0
msg_unknown db 'Comando no reconocido. Escribe help.', 13, 10, 0
msg_help    db 'Comandos disponibles:', 13, 10, ' - clear: Limpia la pantalla', 13, 10, ' - help: Muestra esta ayuda', 13, 10, 0
buffer      times 32 db 0

    times 510-($-$$) db 0
    dw 0xAA55